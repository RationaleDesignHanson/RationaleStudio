module.exports=[42960,a=>{"use strict";a.s([])}];

//# sourceMappingURL=c4062__next-internal_server_app_%28public%29_work_compass_page_actions_b875f6d5.js.map