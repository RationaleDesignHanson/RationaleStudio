globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/be54f29951a7a25f.js",
    "static/chunks/c8d534f254852470.js",
    "static/chunks/11e77576dc3358b5.js",
    "static/chunks/a787bcca85de8a0a.js",
    "static/chunks/turbopack-cd11ed5e4f3ae436.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];